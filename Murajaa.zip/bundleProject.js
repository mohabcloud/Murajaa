import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.join(process.env.USERPROFILE || process.env.HOME, 'Downloads');

// ⚙️ عدد الأجزاء للتقسيم
const NUM_PARTS = 4;
const MIN_SPLIT_SIZE = 40000; // 40KB

// 📋 قائمة الملفات المطلوبة فقط (بالترتيب حسب الأهمية)
const FILES_TO_BUNDLE = [
  // === 1. ملفات الإعداد والنشر ===
  'package.json',
  'vite.config.js',
  'index.html',
  '_routes.json',
  'manifest.json',

  // === 2. نقطة الدخول والستايل ===
  'src/main.jsx',
  'src/App.jsx',
  'src/index.css',

  // === 3. منطق التطبيق (قلب المشروع) ===
  'src/lib/utils.js',
  'src/lib/quranData.js',
  'src/lib/quranPlanEngine.js',
  'src/lib/planStorage.js',
  'src/lib/googleDrive.js',

  // === 4. الصفحات والمكونات الرئيسية ===
  'src/pages/Home.jsx',
  'src/components/quran/CreatePlanForm.jsx',
  'src/components/quran/Dashboard.jsx',
  'src/components/quran/StatCard.jsx',
  'src/components/quran/ScheduleView.jsx',
  'src/components/quran/DayCard.jsx',
  'src/components/quran/FlexibleEntryPanel.jsx',
  'src/components/quran/ProgressRing.jsx',
  'src/components/quran/QuranDetailsPopover.jsx',
  'src/components/QuranInteractivePicker.jsx',
  'src/components/SplashScreen.jsx',

  // === 5. مكونات shadcn المستخدمة فعلاً ===
  'src/components/ui/arabic-date-picker.tsx',
  'src/components/ui/button.jsx',
  'src/components/ui/input.jsx',
  'src/components/ui/label.jsx',
  'src/components/ui/popover.jsx',
  'src/components/ui/select.jsx',
  'src/components/ui/tooltip.jsx',
  'src/components/ui/dialog.jsx',
  'src/components/ui/alert-dialog.jsx',
  'src/components/ui/dropdown-menu.jsx',
];

// 📝 رأس توضيحي يظهر في بداية كل ملف مُجمَّع
const HEADER = `# ============================================================
# 📦 حزمة ملفات مشروع "مُراجِع" - تطبيق مراجعة القرآن
# ============================================================
# 
# 📌 السياق:
# - تطبيق ويب عربي RTL لإدارة مراجعة القرآن، اسمه "مُراجِع".
# - التقنيات: React 18 + Vite + Tailwind + shadcn/ui.
# - الاستضافة: Cloudflare Pages على murajaa.pages.dev.
# - التخزين: Google Drive API (drive.appdata) + localStorage كـ cache.
# - quran_complete_data.json (~2.8MB) موجود ويُستخدم في quranData.js، ولا يُرسل.
#
# ✅ التعديلات الأخيرة المنجزة:
# - استبدال input[type="date"] بـ ArabicDatePicker (react-day-picker + date-fns ar-SA).
# - محاذاة الأيقونات على الهاتف: max-md:items-start + max-md:mt-0.5 في CreatePlanForm/Dashboard/StatCard.
# - إضافة shrink-0 لجميع الأيقونات.
# - إصلاح خروج نص حقول السور: truncate + min-w-0.
#
# ⚠️ المشكلة العالقة:
# - محاذاة النص عمودياً في جميع الحقول على الهاتف (ليست على التابلت/الكمبيوتر).
#
# 🖥️ بيئة التطوير: Windows، npm run dev -- --host، الفتح على الهاتف عبر Network.
# ============================================================

`;

// ============================================================
// أدوات مساعدة
// ============================================================

function splitContentIntoParts(content, numParts) {
  if (numParts <= 1) return [{ index: 1, content }];

  const lines = content.split('\n');
  const totalLines = lines.length;
  const linesPerPart = Math.ceil(totalLines / numParts);
  const parts = [];

  for (let i = 0; i < numParts; i++) {
    const start = i * linesPerPart;
    const end = Math.min(start + linesPerPart, totalLines);
    const partContent = lines.slice(start, end).join('\n');
    if (partContent.trim().length > 0) {
      parts.push({ index: i + 1, content: partContent });
    }
  }

  return parts;
}

function writeBundledFile(baseName, content, forceSplit = false) {
  // حذف أي ملفات قديمة بنفس الاسم
  const oldFiles = fs.readdirSync(outputDir).filter((f) => {
    const baseWithoutExt = path.basename(baseName, '.txt');
    return f === baseName || f.startsWith(`${baseWithoutExt}_part`);
  });
  oldFiles.forEach((f) => fs.unlinkSync(path.join(outputDir, f)));

  // إذا كان صغيراً، اكتبه مباشرة
  if (!forceSplit || content.length < MIN_SPLIT_SIZE) {
    const fullPath = path.join(outputDir, baseName);
    fs.writeFileSync(fullPath, content);
    console.log(`✅ ${baseName} (${(content.length / 1024).toFixed(1)} KB)`);
    return;
  }

  // تقسيم
  console.log(`📦 ${baseName} (${(content.length / 1024).toFixed(1)} KB) → ${NUM_PARTS} أجزاء`);
  const parts = splitContentIntoParts(content, NUM_PARTS);

  parts.forEach((part) => {
    const baseWithoutExt = path.basename(baseName, '.txt');
    const partName = `${baseWithoutExt}_part${part.index}.txt`;
    const partPath = path.join(outputDir, partName);
    fs.writeFileSync(partPath, part.content);
    console.log(`   ✅ ${partName} (${(part.content.length / 1024).toFixed(1)} KB)`);
  });
}

// ============================================================
// التشغيل الرئيسي
// ============================================================

console.log('📦 جاري جمع الملفات المحددة فقط...\n');

let fullContent = HEADER;
const foundFiles = [];
const missingFiles = [];

FILES_TO_BUNDLE.forEach((relativePath) => {
  const fullPath = path.join(__dirname, relativePath);

  if (!fs.existsSync(fullPath)) {
    missingFiles.push(relativePath);
    return;
  }

  try {
    const fileContent = fs.readFileSync(fullPath, 'utf-8');
    fullContent += `\n\n--- FILE: /${relativePath} ---\n\n${fileContent}\n`;
    foundFiles.push(relativePath);
  } catch (err) {
    console.error(`❌ خطأ في قراءة ${relativePath}:`, err.message);
    missingFiles.push(relativePath);
  }
});

// ملخص
console.log(`\n✅ تم جمع ${foundFiles.length} ملف.`);
if (missingFiles.length > 0) {
  console.log(`\n⚠️ ملفات غير موجودة (تم تخطيها):`);
  missingFiles.forEach((f) => console.log(`   - ${f}`));
}

if (foundFiles.length === 0) {
  console.error('\n❌ لا توجد ملفات لجمعها!');
  process.exit(1);
}

// كتابة الملف النهائي (مع تقسيم تلقائي إذا لزم)
console.log('');
writeBundledFile('murajaa_bundle.txt', fullContent, true);

console.log(`\n🎉 تم بنجاح! الملفات موجودة في: ${outputDir}`);
console.log(`📊 الحجم الإجمالي: ${(fullContent.length / 1024).toFixed(1)} KB`);