// src/components/quran/QuranDetailsPopover.jsx
import React, { useState } from "react";
import { Info, BookOpen } from "lucide-react";
import { getVersesBetween, getPageRange, getQuranData } from "@/lib/quranData";
import { toArabicNumbers } from "@/lib/quranPlanEngine";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export default function QuranDetailsPopover({ verses, startPage = 1, className = "" }) {
  const [open, setOpen] = useState(false);
  if (!verses || verses <= 0) return null;

  const endPageExact = findEndPage(verses, startPage);
  const pagesCovered = Math.max(0, endPageExact - startPage + 1);
  const exactVerses = getVersesBetween(startPage, endPageExact);

  const startRange = getPageRange(startPage);
  const endRange = getPageRange(endPageExact);

  const juzCount = Math.floor(pagesCovered / 20);
  const remainingPages = pagesCovered % 20;

  const surahsInRange = getSurahsInRange(startPage, endPageExact);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          className="inline-flex items-center justify-center"
          title="تفاصيل إضافية"
        >
          <Info className="w-4 h-4 stroke-[1.5]" style={{ color: 'hsl(var(--muted-foreground))' }} />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-4" align="start" side="bottom" dir="rtl">
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 mb-2 pb-2 border-b border-border/40">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="font-semibold text-foreground">تفاصيل النطاق</span>
          </div>

          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">الآيات</span>
            <span className="font-semibold text-foreground">{toArabicNumbers(exactVerses)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">الصفحات</span>
            <span className="font-semibold text-foreground">{toArabicNumbers(pagesCovered)}</span>
          </div>

          {juzCount >= 1 && (
            <>
              <div className="border-t border-border/40 pt-2 mt-2" />
              <div className="flex justify-between gap-4">
                <span className="text-muted-foreground">الأجزاء</span>
                <span className="font-semibold text-foreground">
                  {remainingPages > 0
                    ? `${toArabicNumbers(juzCount)} أجزاء و ${toArabicNumbers(remainingPages)} صفحات`
                    : `${toArabicNumbers(juzCount)} أجزاء`}
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-muted-foreground">الأحزاب</span>
                <span className="font-semibold text-foreground">{toArabicNumbers(juzCount * 2)}</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-muted-foreground">الأرباع</span>
                <span className="font-semibold text-foreground">{toArabicNumbers(juzCount * 8)}</span>
              </div>
            </>
          )}

          {surahsInRange.length > 0 && (
            <>
              <div className="border-t border-border/40 pt-2 mt-2" />
              <div className="flex justify-between gap-4">
                <span className="text-muted-foreground">عدد السور</span>
                <span className="font-semibold text-foreground">{toArabicNumbers(surahsInRange.length)}</span>
              </div>
              <div className="text-xs text-muted-foreground pt-1">
                {surahsInRange.slice(0, 8).map((s, i) => (
                  <span key={i} className="inline-block bg-muted/40 rounded-md px-2 py-0.5 ml-1 mb-1">
                    {s}
                  </span>
                ))}
                {surahsInRange.length > 8 && <span className="text-muted-foreground">...وغيرها</span>}
              </div>
            </>
          )}

          <div className="border-t border-border/40 pt-2 mt-2" />
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">من (جزء/صفحة)</span>
            <span className="font-semibold text-foreground">
              {startRange
                ? `ج${toArabicNumbers(startRange.juzu)} · ص${toArabicNumbers(startPage)}`
                : `ص${toArabicNumbers(startPage)}`}
            </span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">إلى (جزء/صفحة)</span>
            <span className="font-semibold text-foreground">
              {endRange
                ? `ج${toArabicNumbers(endRange.juzu)} · ص${toArabicNumbers(endPageExact)}`
                : `ص${toArabicNumbers(endPageExact)}`}
            </span>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function findEndPage(verses, startPage) {
  if (verses <= 0) return startPage;

  const d = getQuranData();
  if (!d) return Math.min(604, startPage + Math.ceil(verses / 10) - 1);

  let remaining = verses;
  let currentPage = Math.max(1, Math.min(604, startPage));

  while (remaining > 0 && currentPage <= 604) {
    const vc = d.pageMap[currentPage]?.verseCount || 10;
    remaining -= vc;
    currentPage++;
  }
  return Math.min(604, currentPage - 1);
}

function getSurahsInRange(startPage, endPage) {
  const d = getQuranData();
  if (!d) return [];

  const surahList = d.surahList || [];
  const surahs = new Set();

  for (const surah of surahList) {
    const sStart = surah.startPage || 1;
    const sEnd = surah.endPage || 604;
    if (sStart <= endPage && sEnd >= startPage) {
      surahs.add(surah.name);
    }
  }

  return Array.from(surahs);
}